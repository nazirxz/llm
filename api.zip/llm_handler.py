from typing import Any, Dict
from langchain_community.chat_models import ChatOllama
from langchain.prompts import PromptTemplate
import logging

logger = logging.getLogger(__name__)

class LLMHandler:
    def __init__(self):
        # Define available models and their configurations
        self.model_configs = {
            "llama3.1": {
                "temperature": 0.1,
                "description": "Llama 3.1 7b Base Model",
            },
            "qwen2.5:1.5b": {
                "temperature": 0.2,
                "description": "Qwen 2.5 1.5B Model",
            },
            "qwen2.5": {
                "temperature": 0.2,
                "description": "Qwen 2.5 7b Base Model",
            },
            "qwen2.5:14b": {
                "temperature": 0.1,
                "description": "Qwen 2.5 14B Large Model",
            },
            "mistral": {
                "temperature": 0.1,
                "description": "Mistral 7b Model"
            },
            "mistral-nemo": {
                "temperature": 0.1,
                "description": "Mistral-Nemo 12b Model"
            }, 
            "bangundwir/bahasa-4b-v2": {
                "temperature": 0.1,
                "description": "Bahasa Indonesia 4b Model"
            }

        }
        self.current_model = "qwen2.5:1.5b"
        self.llm = self._create_llm(self.current_model)
        logger.info(f"Initialized LLMHandler with model: {self.current_model}")

    def _create_llm(self, model_name: str) -> ChatOllama:
        if model_name not in self.model_configs:
            raise ValueError(f"Unsupported model: {model_name}")
        
        config = self.model_configs[model_name]
        logger.info(f"Creating LLM instance for model: {model_name}")
        
        return ChatOllama(
            model=model_name,
            temperature=config["temperature"],
            max_tokens=None,
            timeout=None,
            max_retries=2,
        )

    def switch_model(self, model_name: str) -> None:
        """Switch to a different model."""
        if model_name not in self.model_configs:
            raise ValueError(f"Unsupported model: {model_name}")
        
        logger.info(f"Switching model from {self.current_model} to {model_name}")
        self.current_model = model_name
        self.llm = self._create_llm(model_name)

    def get_current_model(self) -> str:
        """Get the name of the currently active model."""
        return self.current_model

    def get_available_models(self) -> Dict[str, Dict]:
        """Get information about all available models."""
        return self.model_configs

    def create_chain(self, prompt: PromptTemplate, output_parser: Any):
        """Create a processing chain with the current model."""
        return prompt | self.llm | output_parser