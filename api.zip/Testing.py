import json
from typing import List, Dict
from rag_system import RAGSystem
from document_processor import DocumentProcessor
from sentence_transformers import SentenceTransformer

class RAGSystemTester:
    def __init__(self, rag_system: RAGSystem):
        self.rag_system = rag_system

    def generate_test_queries(self, field_names: List[str], well_names: List[str]) -> List[Dict[str, str]]:
        queries = []
        for field in field_names:
            for well in well_names:
                queries.append({
                    "english": f"How much {field} data for well {well}?",
                    "indonesian": f"Berapa {field} di sumur {well}?"
                })
        return queries

    def run_tests(self, field_names: List[str], well_names: List[str]) -> Dict[str, List[Dict[str, str]]]:
        test_queries = self.generate_test_queries(field_names, well_names)
        results = {"english": [], "indonesian": []}

        for query_pair in test_queries:
            for lang in ["english", "indonesian"]:
                query = query_pair[lang]
                response = self.rag_system.process_query(query)
                results[lang].append({
                    "query": query,
                    "answer": response["answer"],
                    "source_documents": response["source_documents"]
                })

        return results

    def save_results(self, results: Dict[str, List[Dict[str, str]]], filename: str):
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)

def main():
    # Initialize the RAG system
    embedding_model = SentenceTransformer("all-MiniLM-L6-v2")
    doc_processor = DocumentProcessor()
    rag_system = RAGSystem(doc_processor, embedding_model)

    # Create the tester
    tester = RAGSystemTester(rag_system)

    # Define test parameters
    field_names = ["average 5 well test before bopd"]
    well_names = ["0D-96", "1D-56", "5D-96"]

    # Run tests
    results = tester.run_tests(field_names, well_names)

    # Save results
    tester.save_results(results, "rag_system_test_results_qwen_1.5b.json")

    print("Testing completed. Results saved to rag_system_test_results_qwen.json")

if __name__ == "__main__":
    main()

