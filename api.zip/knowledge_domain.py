from enum import Enum
from typing import Optional, List

class KnowledgeDomain(str, Enum):
    INTRODUCTION = "introduction"
    GENERAL = "general"
    WELLS = "wells"
    SKKMIGAS = "skkmigas"
    DRILLING = "drilling"

    @classmethod
    def get_default(cls) -> "KnowledgeDomain":
        """Get the default knowledge domain"""
        return cls.INTRODUCTION

class CollectionMapping:
    DOMAIN_TO_COLLECTION = {
        KnowledgeDomain.INTRODUCTION: None,  # Added this line
        KnowledgeDomain.GENERAL: None,
        KnowledgeDomain.WELLS: "Wells_data_txt",
        KnowledgeDomain.SKKMIGAS: "Data_pdf",
        KnowledgeDomain.DRILLING: None
    }

    @classmethod
    def get_collection_name(cls, domain: KnowledgeDomain) -> Optional[str]:
        """Get collection name for single domain"""
        return cls.DOMAIN_TO_COLLECTION.get(domain)

    @classmethod
    def get_collections_for_domains(cls, domains: List[KnowledgeDomain]) -> List[str]:
        """Get collection names for multiple domains"""
        collections = []
        
        # Handle vector store domains
        for domain in domains:
            collection = cls.get_collection_name(domain)
            if collection:  # Only add if collection exists (not None)
                collections.append(collection)
        
        return list(set(collections))  # Remove duplicates if any