import logging
from typing import Dict, Any, List
from langchain.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langgraph.graph import END, StateGraph, START
from typing_extensions import TypedDict
from document_processor import DocumentProcessor
from llm_handler import LLMHandler
from knowledge_router import KnowledgeRouter
from knowledge_domain import KnowledgeDomain, CollectionMapping 
from langchain.schema import Document, HumanMessage
from sentence_transformers import SentenceTransformer
from Models.Models import Metadata, SourceDocument
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.chat_history import BaseChatMessageHistory

# Configure logging
def setup_logger(name: str, log_file: str, level=logging.INFO) -> logging.Logger:
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    file_handler = logging.FileHandler(log_file)
    file_handler.setFormatter(formatter)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger

logger = setup_logger('rag_system', 'rag_system.log')

class GraphState(TypedDict):
    question: str
    generation: str
    documents: List[str]
    chat_history: str
    knowledge_domain: str

class RAGSystem:
    def __init__(self, doc_processor: DocumentProcessor, embedding_model: SentenceTransformer, max_documents: int = 3):
        logger.info("Initializing RAGSystem with DocumentProcessor")
        try:
            self.doc_processor = doc_processor
            self.llm_handler = LLMHandler()
            self.llm = self.llm_handler.llm
            self.embedding_model = embedding_model
            self.max_documents = max_documents
            self.knowledge_router = KnowledgeRouter(doc_processor)
            self.chat_history_store = {}

            self.setup_chains()
            self.setup_workflow()
            logger.info("RAGSystem initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing RAGSystem: {str(e)}", exc_info=True)
            raise

    def setup_chains(self):
        try:
            logger.info("Setting up chains")
            
            # Base template yang berisi perkenalan dan T&C
            base_template = """You are URBuddy:Teman, an AI assistant for Pertamina Hulu Rokan.

            Terms and Conditions:
            1. All information provided should be treated as references only
            2. The accuracy of the information depends on the available data
            3. Users should verify critical information from official sources
            4. This response is AI-generated and may contain uncertainties

            {role_specific}

            Chat History:
            {chat_history}

            Question: {question}

            {context_section}

            Response:"""

            # Introduction specific prompt template
            introduction_template = """You are URBuddy:Teman Pintar Migas,An assistant ai for pertamina hulu rokan and you are in Introduction mode. You must STRICTLY:

            ONLY DO:
            1. Introduce yourself as URBuddy, the AI assistant for Pertamina Hulu Rokan
            2. Respond to greetings (hello, hi, etc.) warmly and professionally
            3. Explain these specific capabilities:
               - Providing information about oil and gas wells
               - Accessing SKKMIGAS regulations
               - Sharing general knowledge about the oil and gas industry
               - Assisting with drilling-related queries
            4. Maintain a professional, friendly tone
            
            NEVER:
            1. Answer technical questions or provide specific data
            2. Engage in general conversation beyond greetings
            3. Provide information about topics outside your introduction
            4. Give opinions or advice
            
            For any question beyond greetings or asking about capabilities:
            1. Politely explain you're in Introduction mode
            2. Guide the user to select an appropriate knowledge domain:
               - Wells Information for well-specific data
               - SKKMIGAS for regulatory information
               - General Knowledge for industry information
               - Drilling for drilling-related queries

            Current Mode: Introduction Mode
            Chat History: {chat_history}
            User Question: {question}

            Please provide an appropriate introduction response:"""

            # Create the introduction handler chain
            self.intro_handler = PromptTemplate(
                template=introduction_template,
                input_variables=["chat_history", "question"]
            ) | self.llm | StrOutputParser()

            # Role-specific content for other domains
            role_contents = {
                "intro_general": """
                I can:
                1. Introduce myself as URBuddy
                2. Respond to greetings
                3. Provide general information about Pertamina Hulu Rokan
                4. Share basic knowledge about oil and gas industry
                """,

                "intro_wells": """
                I can:
                1. Introduce myself as URBuddy
                2. Respond to greetings
                3. Provide specific well information based on available data
                4. Share technical details about wells
                """,

                "intro_skkmigas": """
                I can:
                1. Introduce myself as URBuddy
                2. Respond to greetings
                3. Provide information about SKKMIGAS regulations
                4. Share details from SKKMIGAS documentation
                """,

                "wells_skkmigas": """
                I can:
                1. Provide well-specific information
                2. Share SKKMIGAS regulatory information
                3. Combine well data with relevant SKKMIGAS context
                """,
            }

            # Create prompts for each possible combination
            self.prompts = {}
            
            # Single domain prompts
            self.prompts["introduction"] = PromptTemplate(
                template=base_template.format(
                    role_specific="""I am in Introduction mode and STRICTLY ONLY:
                    1. Introduce myself as URBuddy, an AI assistant for Pertamina Hulu Rokan
                    2. Respond to greetings like 'hello', 'hi', etc
                    3. Explain my capabilities specific to oil and gas operations
                    4. Use professional tone
                    
                    I CANNOT:
                    1. Answer general questions outside of self-introduction
                    2. Provide any information about topics not related to my introduction
                    3. Engage in general conversation
                    4. Answer questions about oil and gas (please use General Knowledge mode for that)
                    
                    If user asks anything outside of introduction/greeting, I should politely inform them to select appropriate knowledge domain.""",
                    context_section="",
                    chat_history="{chat_history}",
                    question="{question}"
                ),
                input_variables=["chat_history", "question"]
            )

            # Update di setup_chains untuk general domain
            self.prompts["general"] = PromptTemplate(
                template=base_template.format(
                    role_specific="""I am URBuddy: Teman Pintar Migas, Pertamina Hulu Rokan AI Assistant, and I can:
                    1. Answer a wide range of general knowledge questions.
                    2. Provide information about various topics.
                    3. Engage in discussions about current events and general trivia.
                    
                    I CANNOT and SHOULD NOT:
                    1. Provide personal opinions or advice.
                    2. Discuss sensitive or inappropriate topics.
                    3. Offer information that is outside my training or knowledge base.
                    
                    If the user asks anything outside of my knowledge, I should politely inform them that I can only assist with general knowledge queries.""",
                    context_section="",
                    chat_history="{chat_history}",
                    question="{question}"
                ),
                input_variables=["chat_history", "question"]
            )

            # Vector store prompts (untuk wells dan skkmigas)
            self.prompts["vectorstore"] = PromptTemplate(
                template=base_template.format(
                    role_specific="""I will use the following context to provide accurate information.""",
                    context_section="Context:\n{context}",
                    chat_history="{chat_history}",
                    question="{question}"
                ),
                input_variables=["context", "chat_history", "question"]
            )

            # Add more combinations
            for domain_combo, role_content in role_contents.items():
                template = base_template.format(
                    role_specific=role_content,
                    context_section="{context}" if any(x in domain_combo for x in ['wells', 'skkmigas']) else "",
                    chat_history="{chat_history}",
                    question="{question}"
                )
                
                input_vars = ["chat_history", "question"]
                if any(x in domain_combo for x in ['wells', 'skkmigas']):
                    input_vars.append("context")
                    
                self.prompts[domain_combo] = PromptTemplate(
                    template=template,
                    input_variables=input_vars
                )

            # Create chains for all prompts
            self.chains = {
                name: prompt | self.llm | StrOutputParser()
                for name, prompt in self.prompts.items()
            }

            logger.info("Chain setup completed successfully")
        except Exception as e:
            logger.error(f"Error setting up chains: {str(e)}", exc_info=True)
            raise

    def setup_workflow(self):
        try:
            logger.info("Setting up workflow")
            workflow = StateGraph(GraphState)

            # Define nodes
            workflow.add_node("route_knowledge", self.knowledge_router.route_query)
            workflow.add_node("handle_general", self.handle_general_response)
            workflow.add_node("handle_vectorstore", self.handle_vectorstore_response)
            workflow.add_node("handle_intro", self.handle_intro)

            # Build graph
            workflow.add_conditional_edges(
                START,
                self.determine_workflow,
                {
                    "introduction": "handle_intro",
                    "knowledge_query": "route_knowledge"
                }
            )

            workflow.add_conditional_edges(
                "route_knowledge",
                self.determine_response_type,
                {
                    "general": "handle_general",
                    "vectorstore": "handle_vectorstore"
                }
            )

            workflow.add_edge("handle_intro", END)
            workflow.add_edge("handle_general", END)
            workflow.add_edge("handle_vectorstore", END)

            self.app = workflow.compile()
            logger.info("Workflow setup completed successfully")
        except Exception as e:
            logger.error(f"Error setting up workflow: {str(e)}", exc_info=True)
            raise
    def determine_workflow(self, state: Dict[str, Any]) -> str:
        """Determine if this is an introduction or knowledge query"""
        question = state["question"].lower()
        if any(word in question for word in ['hello', 'hi', 'greetings', 'introduce']):
            logger.info("Query classified as introduction")
            return "introduction"
        logger.info("Query classified as knowledge query")
        return "knowledge_query"

    def determine_response_type(self, state: Dict[str, Any]) -> str:
        question_type = state.get("question_type", "")
        knowledge_domain = state.get("knowledge_domain", "general")
        logger.info(f"Determining response type for question type: {question_type} in domain: {knowledge_domain}")
        if question_type in [KnowledgeDomain.WELLS, KnowledgeDomain.SKKMIGAS]:
            logger.info("Using vectorstore response handler")
            return "vectorstore"
        logger.info("Using general response handler")
        return "general"

    async def handle_vectorstore_response(
        self, 
        query: str, 
        documents: List[Document], 
        chat_history: str,
        domain_key: str
    ) -> Dict[str, Any]:
        """
        Handle responses that require vector store context
        """
        try:
            logger.info(f"Handling vectorstore response for query with domain key: {domain_key}")
            
            if not documents:
                no_docs_message = (
                    f"I couldn't find any relevant documents to answer your question. "
                    "Could you please rephrase your question or ask about something else?"
                )
                return {
                    "question": query,
                    "answer": no_docs_message,
                    "source_documents": [],
                    "domain": domain_key
                }

            # Prepare context from documents
            context = self.prepare_context(documents)
            logger.info("Context prepared from documents")

            # Use appropriate chain based on domain combination
            chain = self.chains.get("vectorstore")
            if not chain:
                logger.error("Vectorstore chain not found")
                raise ValueError("Vectorstore chain not properly initialized")

            # Generate response using appropriate chain
            response = await chain.ainvoke({
                "context": context,
                "question": query,
                "chat_history": chat_history
            })
            
            # Process source documents
            source_documents = []
            for doc in documents:
                try:
                    source_doc = SourceDocument(
                        content=doc.page_content[:200] + "...",
                        metadata=Metadata(**doc.metadata)
                    )
                    source_documents.append(source_doc.dict())
                except Exception as doc_error:
                    logger.error(f"Error processing document: {str(doc_error)}")
                    continue
            
            logger.info(f"Vectorstore response generated successfully for domain: {domain_key}")
            return {
                "question": query,
                "answer": response,
                "source_documents": source_documents,
                "domain": domain_key
            }

        except Exception as e:
            logger.error(f"Error in vectorstore response: {str(e)}")
            error_message = (
                "I encountered an error while searching the knowledge base. "
                "Please try rephrasing your question."
            )
            return {
                "question": query,
                "answer": error_message,
                "source_documents": [],
                "domain": domain_key
            }

    
    async def check_ollama_connection(self) -> bool:
        """Check if Ollama server is accessible"""
        try:
            # Simple test query
            await self.general_prompt.ainvoke({
                "question": "test",
                "chat_history": ""
            })
            return True
        except Exception as e:
            logger.error(f"Ollama connection check failed: {str(e)}")
            return False


    async def handle_general_response(
        self, 
        query: str, 
        chat_history: str,
        domain_key: str
    ) -> Dict[str, Any]:
        """Handle general knowledge responses"""
        try:
            logger.info(f"Handling response for query with domain key: {domain_key}")
            
            if domain_key == "introduction":
                # Introduction mode handling...
                greeting_patterns = ['hello', 'hi', 'hey', 'greetings', 'introduce', 
                                'what can you do', 'who are you', 'what are you']
                
                if not any(pattern in query.lower() for pattern in greeting_patterns):
                    return {
                        "question": query,
                        "answer": ("I apologize, but I'm currently in Introduction mode and can only "
                                "respond to greetings and explain my capabilities. Please select an "
                                "appropriate knowledge domain (like General Knowledge) if you want "
                                "to ask other types of questions."),
                        "source_documents": [],
                        "domain": domain_key
                    }
            
            elif domain_key == "general":
                # Allow all general knowledge queries
                # No need to check for unrelated keywords anymore
                
                # Use appropriate chain based on domain combination
                chain = self.chains.get(domain_key) or self.chains.get("introduction")
                
                try:
                    response = await chain.ainvoke({
                        "question": query,
                        "chat_history": chat_history
                    })
                except Exception as chain_error:
                    if "500 Internal Server Error" in str(chain_error):
                        logger.error("Chain execution error: %s", str(chain_error))
                        return {
                            "question": query,
                            "answer": "I apologize, but I'm currently having trouble processing your request. Please try again in a few moments.",
                            "source_documents": [],
                            "domain": domain_key,
                        }
                    raise
                
                logger.info("Response generated successfully")
                return {
                    "question": query,
                    "answer": response,
                    "source_documents": [],
                    "domain": domain_key
                }

        except Exception as e:
            logger.error(f"Error in response: {str(e)}")
            error_message = "I encountered an error while generating a response. Please try asking your question again."
            
            return {
                "question": query,
                "answer": error_message,
                "source_documents": [],
                "domain": domain_key
            }
    
    def handle_intro(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Handle introduction and greeting responses"""
        try:
            question = state["question"]
            chat_history = state.get("chat_history", "")
            logger.info(f"Handling introduction: {question}")
            
            response = self.intro_handler.invoke({
                "question": question,
                "chat_history": chat_history
            })
            
            logger.info("Introduction handled successfully")
            return {
                "question": question, 
                "generation": response,
                "chat_history": chat_history
            }
        except Exception as e:
            logger.error(f"Error handling introduction: {str(e)}", exc_info=True)
            return {
                "question": question, 
                "generation": "An error occurred while processing the introduction.",
                "chat_history": chat_history
            }
    def prepare_context(self, documents: List[Document]) -> str:
        """Prepare context from documents for response generation"""
        context = []
        for doc in documents:
            if 'wells_name' in doc.metadata:
                context.append(
                    f"Source: {doc.metadata.get('source', 'Unknown')}\n"
                    f"Well: {doc.metadata.get('wells_name', 'Unknown')}\n"
                    f"Content: {doc.page_content}"
                )
            elif 'document_name' in doc.metadata:
                context.append(
                    f"Document: {doc.metadata.get('document_name', 'Unknown')}\n"
                    f"Page: {doc.metadata.get('number_page', 'Unknown')}\n"
                    f"Content: {doc.page_content}"
                )
            else:
                context.append(doc.page_content)
        
        formatted_context = "\n\n".join(context)
        logger.debug(f"Prepared context (first 500 chars): {formatted_context[:500]}...")
        return formatted_context

    # Chat History Management Methods
    def get_session_history(self, session_id: str) -> BaseChatMessageHistory:
        """Get or create chat history for a specific session"""
        if session_id not in self.chat_history_store:
            logger.info(f"Creating new chat history for session {session_id}")
            self.chat_history_store[session_id] = ChatMessageHistory()
        return self.chat_history_store[session_id]

    def get_formatted_chat_history(self, session_id: str) -> str:
        """Get formatted chat history for a specific session"""
        chat_history = self.get_session_history(session_id)
        if not chat_history.messages:
            return ""
        
        formatted_history = []
        for message in chat_history.messages:
            role = "User" if message.type == "human" else "Assistant"
            formatted_history.append(f"{role}: {message.content}")
        
        return "\n".join(formatted_history)

    def update_chat_history(self, session_id: str, role: str, content: str):
        """Update chat history for a specific session"""
        chat_history = self.get_session_history(session_id)
        if role == "human":
            chat_history.add_user_message(content)
        else:
            chat_history.add_ai_message(content)
        logger.info(f"Updated chat history for session {session_id}")
    
    # Model Management Methods
    def switch_model(self, model_name: str):
        """Switch to a different LLM model"""
        try:
            logger.info(f"Switching to model: {model_name}")
            self.llm_handler.switch_model(model_name)
            self.llm = self.llm_handler.llm
            self.setup_chains()
            logger.info(f"Successfully switched to model: {model_name}")
        except Exception as e:
            logger.error(f"Error switching model: {str(e)}")
            raise

    def get_current_model(self) -> str:
        """Get the name of the currently active model"""
        return self.llm_handler.get_current_model()

    def get_available_models(self) -> List[str]:
        """Get list of available models"""
        return list(self.llm_handler.get_available_models().keys())

    async def process_query(
        self, 
        query: str, 
        session_id: str, 
        selected_domains: List[str] = None
    ) -> Dict[str, Any]:
        """Process query based on selected domains"""
        logger.info(f"Processing query for session {session_id} with domains: {selected_domains}")
        
        try:
            # Use introduction as default if no domains selected
            if not selected_domains:
                selected_domains = [KnowledgeDomain.INTRODUCTION.value]
            
            # Convert string domains to enum
            domain_enums = [KnowledgeDomain(domain) for domain in selected_domains]
            
            # Get chat history
            chat_history = self.get_formatted_chat_history(session_id)
            self.update_chat_history(session_id, "human", query)

            try:
                # Check if we're in introduction mode
                if "introduction" in selected_domains:
                    logger.info("Using introduction handler")
                    # Create state dict for handle_intro
                    state = {
                        "question": query,
                        "chat_history": chat_history
                    }
                    
                    # Call handle_intro with just the state dictionary
                    intro_result = self.handle_intro(state)
                    
                    # Format the response
                    response = {
                        "question": query,
                        "answer": intro_result.get("generation", ""),
                        "source_documents": [],
                        "domain": "introduction"
                    }
                else:
                    # Rest of the existing code for other domains...
                    collections = CollectionMapping.get_collections_for_domains(domain_enums)
                    logger.info(f"Using collections: {collections}")

                    if collections:
                        # Existing vector store handling code...
                        all_documents = []
                        skkmigas_documents = []
                        wells_documents = []
                        
                        for domain in domain_enums:
                            router_result = await self.knowledge_router.route_query(
                                query,
                                domain,
                                self.embedding_model
                            )
                            if router_result.get("documents"):
                                if domain == KnowledgeDomain.SKKMIGAS:
                                    skkmigas_documents.extend(router_result["documents"])
                                elif domain == KnowledgeDomain.WELLS:
                                    wells_documents.extend(router_result["documents"])
                        
                        if "ptk" in query.lower() or "skkmigas" in query.lower() or "regulasi" in query.lower():
                            all_documents = skkmigas_documents if skkmigas_documents else wells_documents
                        elif any(well_term in query.lower() for well_term in ["well", "sumur", "bopd", "pressure"]):
                            all_documents = wells_documents if wells_documents else skkmigas_documents
                        else:
                            all_documents = skkmigas_documents + wells_documents
                        
                        if all_documents:
                            response = await self.handle_vectorstore_response(
                                query,
                                all_documents[:5],
                                chat_history,
                                "_".join([d.value for d in domain_enums])
                            )
                        else:
                            response = await self.handle_general_response(
                                query,
                                chat_history,
                                "_".join([d.value for d in domain_enums])
                            )
                    else:
                        response = await self.handle_general_response(
                            query,
                            chat_history,
                            "_".join([d.value for d in domain_enums])
                        )

                # Update chat history with the response
                if "answer" in response:
                    self.update_chat_history(session_id, "assistant", response["answer"])
                
                return {
                    **response,
                    "selected_domains": selected_domains
                }

            except Exception as processing_error:
                logger.error(f"Error processing query: {str(processing_error)}")
                return self._handle_process_query_error(query, str(processing_error), session_id)

        except Exception as e:
            logger.error(f"Critical error in process_query: {str(e)}")
            return self._handle_process_query_error(query, str(e), session_id)
    def _handle_process_query_error(
        self, 
        query: str, 
        error_msg: str, 
        session_id: str
    ) -> Dict[str, Any]:
        """Handle errors in process_query"""
        error_message = (
            "I apologize, but I encountered an error while processing your query. "
            "Please try asking your question in a different way."
        )
        
        try:
            self.update_chat_history(session_id, "assistant", error_message)
        except Exception as history_error:
            logger.error(f"Failed to update chat history: {str(history_error)}")

        return {
            "question": query,
            "answer": error_message,
            "source_documents": []
        }

    def log_document_details(self, documents: List[Document]):
        """Log details about processed documents"""
        for i, doc in enumerate(documents, 1):
            logger.info(f"Document {i}:")
            logger.info(f"  Source: {doc.metadata.get('source', 'Unknown')}")
            logger.info(f"  Wells Name: {doc.metadata.get('wells_name', 'N/A')}")
            logger.info(f"  Page: {doc.metadata.get('page', 'N/A')}")
            logger.info(f"  Content (first 100 chars): {doc.page_content[:100]}...")