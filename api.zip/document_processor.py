from pymilvus import connections, Collection, utility
from typing import List, Any, Dict
import logging

logger = logging.getLogger(__name__)
class DocumentProcessor:
    def __init__(self):
        self.connect_to_milvus()
        self.collections = {
            "Wells_data_txt": self.load_collection("Wells_data_txt"),
            "Data_pdf": self.load_collection("Data_pdf")
        }
        self.well_names_cache = {}  # Cache for well names


    def connect_to_milvus(self):
        connections.connect(host='localhost', port='19530')

    def load_collection(self, collection_name: str) -> Collection:
        try:
            if utility.has_collection(collection_name):
                print(f"Loading collection '{collection_name}'...")
                collection = Collection(collection_name)
                collection.load()
                return collection
            else:
                raise ValueError(f"Collection '{collection_name}' does not exist.")
        except Exception as e:
            print(f"Error loading collection: {str(e)}")
            raise

    def search_documents(self, query_vector, collection_name: str, limit=5):
        if collection_name not in self.collections:
            raise ValueError(f"Unknown collection: {collection_name}")
        
        collection = self.collections[collection_name]
        search_params = {"metric_type": "L2", "params": {"nprobe": 10}}
        
        if collection_name == "Wells_data_txt":
            output_fields = ["text", "wells_name", "source_document"]
        elif collection_name == "Data_pdf":
            output_fields = ["text", "number_page", "document_name"]
        else:
            output_fields = ["text", "source_document"]

        results = collection.search(
            data=[query_vector],
            anns_field="vector",
            param=search_params,
            limit=limit,
            output_fields=output_fields
        )
        return results[0]

    def search_documents_by_well_names(self, well_names: List[str], collection_name: str, limit: int = 5) -> List[Dict[str, Any]]:
        if collection_name != "Wells_data_txt":
            raise ValueError("This method is only applicable for the Wells_data_txt collection")
        
        collection = self.collections[collection_name]
        
        expr = " || ".join([f'wells_name == "{name}"' for name in well_names])
        logger.info(f"Searching documents with expression: {expr}")
        results = collection.query(
            expr=expr,
            output_fields=["text", "wells_name", "source_document"],
            limit=limit
        )
        
        logger.info(f"Found {len(results)} documents matching the well names")
        
        processed_results = []
        for result in results:
            source_doc = result.get('source_document', 'Unknown')
            wells_name = result.get('wells_name', 'Unknown')
            logger.info(f"Raw result - Well: {wells_name}, Source: {source_doc}")
            
            # Construct the source if it's not present
            if source_doc == 'Unknown' and wells_name != 'Unknown':
                source_doc = f"{wells_name}.txt"
                logger.info(f"Constructed source document: {source_doc}")
            
            processed_result = {
                'text': result.get('text', ''),
                'wells_name': wells_name,
                'source_document': source_doc
            }
            processed_results.append(processed_result)
            logger.info(f"Processed result - Well: {wells_name}, Source: {source_doc}")
        
        return processed_results

    def get_all_well_names(self, collection_name: str) -> List[str]:
        if collection_name != "Wells_data_txt":
            raise ValueError("This method is only applicable for the Wells_data_txt collection")
        
        if collection_name in self.well_names_cache:
            logger.info(f"Returning cached well names for {collection_name}")
            return self.well_names_cache[collection_name]
        
        collection = self.collections[collection_name]
        logger.info(f"Querying well names from collection: {collection_name}")
        
        all_well_names = set()
        offset = 0
        limit = 10000  # Set a reasonable limit per query
        
        while True:
            results = collection.query(
                expr="wells_name != ''",
                output_fields=["wells_name"],
                offset=offset,
                limit=limit
            )
            
            if not results:
                break
            
            well_names = set(result['wells_name'] for result in results)
            all_well_names.update(well_names)
            
            if len(results) < limit:
                break
            
            offset += limit
        
        well_names_list = list(all_well_names)
        logger.info(f"Retrieved {len(well_names_list)} unique well names from {collection_name}")
        
        self.well_names_cache[collection_name] = well_names_list
        
        return well_names_list