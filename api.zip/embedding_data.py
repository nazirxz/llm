import os
import logging
from typing import List, Dict, Tuple
import torch
from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
from pymilvus import Collection, connections, utility, FieldSchema, CollectionSchema, DataType
from langchain_community.document_loaders import TextLoader
from pdf_extractor import PDFExtractor
from tqdm.auto import tqdm  # Change this line


logger = logging.getLogger(__name__)

class MultimodalDataEmbedder:
    def __init__(self, data_folder: str, embedding_name: str, chunk_size: int = 500, 
                 chunk_overlap: int = 50, batch_size: int = 1000, ocr_language: str = 'eng', ocr_dpi: int = 300):
        self.data_folder = data_folder
        self.model = SentenceTransformer(embedding_name)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        self.collections = {}
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.batch_size = batch_size
        self.pdf_extractor = PDFExtractor(ocr_language=ocr_language, dpi=ocr_dpi)
        logger.info(f"Initialized MultimodalDataEmbedder with data folder: {data_folder}, "
                    f"embedding model: {embedding_name}, chunk size: {chunk_size}, "
                    f"chunk overlap: {chunk_overlap}, batch size: {batch_size}, "
                    f"OCR language: {ocr_language}, OCR DPI: {ocr_dpi}")

    def connect_to_milvus(self, host: str = 'localhost', port: str = '19530'):
        connections.connect(host=host, port=port)
        logger.info(f"Connected to Milvus at {host}:{port}")

    def create_collection(self, collection_name: str, fields: List[FieldSchema]) -> Collection:
        if not utility.has_collection(collection_name):
            schema = CollectionSchema(fields, description=f"{collection_name} collection")
            collection = Collection(collection_name, schema=schema)
            logger.info(f"Created new collection: {collection_name}")
        else:
            collection = Collection(collection_name)
            logger.info(f"Loaded existing collection: {collection_name}")
        return collection

    def get_collection(self, file_type: str) -> Collection:
        if file_type not in self.collections:
            if file_type == 'txt':
                fields = [
                    FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
                    FieldSchema(name="text", dtype=DataType.VARCHAR, max_length=65535, is_primary=False),
                    FieldSchema(name="vector", dtype=DataType.FLOAT_VECTOR, dim=384),
                    FieldSchema(name="wells_name", dtype=DataType.VARCHAR, max_length=255, is_primary=False),
                    FieldSchema(name="source_document", dtype=DataType.VARCHAR, max_length=255, is_primary=False),
                ]
                collection_name = "Wells_data_txt"
            elif file_type == 'pdf':
                fields = [
                    FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
                    FieldSchema(name="text", dtype=DataType.VARCHAR, max_length=65535, is_primary=False),
                    FieldSchema(name="number_page", dtype=DataType.INT64, is_primary=False),
                    FieldSchema(name="vector", dtype=DataType.FLOAT_VECTOR, dim=384),
                    FieldSchema(name="document_name", dtype=DataType.VARCHAR, max_length=255, is_primary=False),
                ]
                collection_name = "Data_pdf"
            else:
                raise ValueError(f"Unsupported file type: {file_type}")

            self.collections[file_type] = self.create_collection(collection_name, fields)

        return self.collections[file_type]

    def load_document(self, file_path: str) -> List[Document]:
        ext = os.path.splitext(file_path)[1].lower()
        logger.info(f"Loading document: {file_path}")
        try:
            if ext == '.txt':
                docs = TextLoader(file_path, encoding='utf-8').load()
            elif ext == '.pdf':
                docs = self.pdf_extractor.extract_text_from_pdf(file_path)
            else:
                logger.error(f"Unsupported file type: {ext}")
                raise ValueError(f"Unsupported file type: {ext}")
            logger.info(f"Successfully loaded {len(docs)} documents from {file_path}")
            return docs
        except Exception as e:
            logger.error(f"Error loading {file_path}: {str(e)}")
            return []

    @staticmethod
    def clean_text(text: str) -> str:
        return ' '.join(text.split())

    def process_documents(self, documents: List[Document]) -> List[Document]:
        logger.info(f"Processing {len(documents)} documents")
        processed_docs = []
        for doc in documents:
            cleaned_text = self.clean_text(doc.page_content)
            metadata = doc.metadata.copy()
            metadata['char_count'] = len(cleaned_text)
            metadata['word_count'] = len(cleaned_text.split())
            processed_docs.append(Document(page_content=cleaned_text, metadata=metadata))
        logger.info(f"Processed {len(processed_docs)} documents")
        return processed_docs

    def load_all_documents(self) -> List[Tuple[str, List[Document]]]:
        all_documents = []
        for filename in os.listdir(self.data_folder):
            file_path = os.path.join(self.data_folder, filename)
            if os.path.isfile(file_path):
                ext = os.path.splitext(file_path)[1].lower()[1:]  # Remove the dot
                if ext in ['txt', 'pdf']:
                    docs = self.load_document(file_path)
                    if docs:
                        all_documents.append((ext, docs))
                else:
                    logger.warning(f"Skipping unsupported file: {filename}")
        return all_documents

    def process_and_embed_documents(self, all_documents: List[Tuple[str, List[Document]]]) -> Tuple[List[Dict], List[Dict]]:
        txt_entities = []
        pdf_entities = []
        all_chunks = []
        
        logger.info("Processing all documents")
        for file_type, docs in all_documents:
            processed_docs = self.process_documents(docs)
            text_splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap,
                separators=["\n\n", "\n", " ", ""]
            )
            chunks = text_splitter.split_documents(processed_docs)
            all_chunks.extend([(file_type, chunk) for chunk in chunks])
        
        logger.info(f"Split all documents into {len(all_chunks)} chunks")

        # Process all chunks in batches
        for i in tqdm(range(0, len(all_chunks), self.batch_size), desc="Batches"):
            batch = all_chunks[i:i+self.batch_size]
            texts = [chunk.page_content for _, chunk in batch]
            vectors = self.model.encode(texts).tolist()

            for (file_type, chunk), vector in zip(batch, vectors):
                entity = {
                    "text": chunk.page_content,
                    "vector": vector,
                }
                if file_type == 'txt':
                    # Remove 'Data/' prefix and '.txt' suffix from wells_name
                    wells_name = os.path.basename(chunk.metadata.get('source', ''))
                    wells_name = os.path.splitext(wells_name)[0]  # Remove file extension
                    entity["wells_name"] = wells_name
                    entity["source_document"] = chunk.metadata.get('source', '')
                    txt_entities.append(entity)
                elif file_type == 'pdf':
                    entity["document_name"] = os.path.basename(chunk.metadata.get('source', ''))
                    entity["number_page"] = chunk.metadata.get('page', 1)
                    pdf_entities.append(entity)

            logger.info(f"Processed batch of {len(batch)} chunks")

        logger.info(f"Processed and embedded {len(txt_entities)} txt entities and {len(pdf_entities)} pdf entities")
        return txt_entities, pdf_entities

    def insert_documents(self, txt_entities: List[Dict], pdf_entities: List[Dict]):
        if txt_entities:
            txt_collection = self.get_collection('txt')
            for i in range(0, len(txt_entities), self.batch_size):
                batch = txt_entities[i:i+self.batch_size]
                txt_collection.insert(batch)
                logger.info(f"Inserted batch of {len(batch)} txt entities")
            txt_collection.flush()
            self.create_index(txt_collection)

        if pdf_entities:
            pdf_collection = self.get_collection('pdf')
            for i in range(0, len(pdf_entities), self.batch_size):
                batch = pdf_entities[i:i+self.batch_size]
                pdf_collection.insert(batch)
                logger.info(f"Inserted batch of {len(batch)} pdf entities")
            pdf_collection.flush()
            self.create_index(pdf_collection)

    def create_index(self, collection: Collection):
        index_params = {
            "index_type": "HNSW",
            "metric_type": "L2",
            "params": {"M": 16, "efConstruction": 200}
        }
        try:
            logger.info(f"Creating index on vector field for collection {collection.name}")
            collection.create_index("vector", index_params)
            logger.info(f"Index created successfully on vector field for collection {collection.name}")
        except Exception as e:
            logger.error(f"Error creating index for collection {collection.name}: {str(e)}", exc_info=True)
            raise

    def load_data_from_milvus(self, file_type: str) -> List[Dict]:
        collection = self.get_collection(file_type)
        collection.load()
        
        # Get the field names as strings
        output_fields = [field.name for field in collection.schema.fields]
        
        try:
            results = collection.query(
                expr="id >= 0",  # This will retrieve all records
                output_fields=output_fields,
                limit=collection.num_entities
            )
            
            logger.info(f"Successfully loaded {len(results)} entities from {file_type} collection")
            return results
        except Exception as e:
            logger.error(f"Error querying {file_type} collection: {str(e)}")
            return []
        finally:
            collection.release()

    def embed_and_insert_documents(self):
        try:
            logger.info("Starting document loading process")
            all_documents = self.load_all_documents()
            logger.info(f"Loaded {len(all_documents)} documents in total")

            logger.info("Starting document processing and embedding")
            txt_entities, pdf_entities = self.process_and_embed_documents(all_documents)
            logger.info(f"Processed and embedded {len(txt_entities)} txt entities and {len(pdf_entities)} pdf entities")

            logger.info("Starting document insertion process")
            self.insert_documents(txt_entities, pdf_entities)
            logger.info("Document insertion process completed successfully")

            logger.info("Loading inserted data from Milvus")
            loaded_txt_data = self.load_data_from_milvus('txt')
            loaded_pdf_data = self.load_data_from_milvus('pdf')
            logger.info(f"Loaded {len(loaded_txt_data)} txt entities and {len(loaded_pdf_data)} pdf entities from Milvus")

            return loaded_txt_data, loaded_pdf_data
        except Exception as e:
            logger.error(f"Error in embed_and_insert_documents: {str(e)}", exc_info=True)
            raise

    @classmethod
    def main(cls, data_folder: str, embedding_name: str):
        logger.info(f"Starting main process with data folder: {data_folder}, embedding model: {embedding_name}")
        try:
            embedder = cls(data_folder, embedding_name)
            embedder.connect_to_milvus()
            loaded_txt_data, loaded_pdf_data = embedder.embed_and_insert_documents()
            logger.info("Document embedding, insertion, and loading process completed successfully")
            logger.info(f"Loaded {len(loaded_txt_data)} txt entities and {len(loaded_pdf_data)} pdf entities")
            # Here you can process or use the loaded data as needed
        except Exception as e:
            logger.error(f"Error in main process: {str(e)}", exc_info=True)
            raise
        finally:
            connections.disconnect("default")
            logger.info("Disconnected from Milvus")