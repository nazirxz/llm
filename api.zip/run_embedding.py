import argparse
import logging
import os
from embedding_data import MultimodalDataEmbedder
from pymilvus import connections

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def setup_argparse():
    parser = argparse.ArgumentParser(description='Multimodal Data Embedding and Insertion Tool')
    parser.add_argument('--data_folder', type=str, default='Data', help='Path to the data folder')
    parser.add_argument('--embedding_model', type=str, default='all-MiniLM-L6-v2', help='Name of the embedding model to use')
    parser.add_argument('--milvus_host', type=str, default='localhost', help='Milvus server host')
    parser.add_argument('--milvus_port', type=int, default=19530, help='Milvus server port')
    parser.add_argument('--chunk_size', type=int, default=500, help='Chunk size for text splitting')
    parser.add_argument('--chunk_overlap', type=int, default=50, help='Chunk overlap for text splitting')
    parser.add_argument('--batch_size', type=int, default=1000, help='Batch size for processing and insertion')
    parser.add_argument('--ocr_language', type=str, default='eng', help='Language for OCR')
    parser.add_argument('--ocr_dpi', type=int, default=300, help='DPI for OCR')
    return parser

def main(args):
    logger.info(f"Starting main process with data folder: {args.data_folder}")
    logger.info(f"Using embedding model: {args.embedding_model}")
    logger.info(f"Chunk size: {args.chunk_size}, Chunk overlap: {args.chunk_overlap}, Batch size: {args.batch_size}")

    try:
        # Initialize MultimodalDataEmbedder
        embedder = MultimodalDataEmbedder(
            data_folder=args.data_folder,
            embedding_name=args.embedding_model,
            chunk_size=args.chunk_size,
            chunk_overlap=args.chunk_overlap,
            batch_size=args.batch_size,
            ocr_language=args.ocr_language,
            ocr_dpi=args.ocr_dpi
        )

        # Connect to Milvus
        embedder.connect_to_milvus(args.milvus_host, args.milvus_port)

        # Embed, insert documents, and load data
        loaded_txt_data, loaded_pdf_data = embedder.embed_and_insert_documents()

        logger.info("Document embedding, insertion, and loading process completed successfully")
        logger.info(f"Loaded {len(loaded_txt_data)} txt entities and {len(loaded_pdf_data)} pdf entities")

        # Here you can add any additional processing or analysis of the loaded data
        # For example:
        # process_loaded_data(loaded_txt_data, loaded_pdf_data)

    except Exception as e:
        logger.error(f"Error in main process: {str(e)}", exc_info=True)
    finally:
        # Disconnect from Milvus
        try:
            connections.disconnect("default")
            logger.info("Disconnected from Milvus")
        except Exception as e:
            logger.error(f"Error disconnecting from Milvus: {str(e)}")

# Uncomment and implement this function if you want to do additional processing
# def process_loaded_data(txt_data, pdf_data):
#     logger.info("Processing loaded data...")
#     # Add your data processing logic here
#     pass

if __name__ == "__main__":
    parser = setup_argparse()
    args = parser.parse_args()

    # Validate data folder
    if not os.path.isdir(args.data_folder):
        logger.error(f"Data folder does not exist: {args.data_folder}")
        exit(1)

    main(args)