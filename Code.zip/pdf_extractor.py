import logging
from typing import List, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from pdf2image import convert_from_path
import pytesseract
from langchain.schema import Document
try:
    import fitz
except ImportError:
    import PyMuPDF as fitz
import os

logger = logging.getLogger(__name__)

if os.name == 'nt':
    tesseract_path = r'C:\Program Files\Tesseract-OCR\tesseract.exe'  # Adjust this path if necessary
    if os.path.exists(tesseract_path):
        pytesseract.pytesseract.tesseract_cmd = tesseract_path
    else:
        raise RuntimeError("Tesseract is not found. Please install it and set the correct path.")

class PDFExtractor:
    def __init__(self, ocr_language: str = 'eng', dpi: int = 300):
        self.ocr_language = ocr_language
        self.dpi = dpi

    def extract_text_from_pdf(self, file_path: str) -> List[Document]:
        logger.info(f"Extracting text from PDF: {file_path}")
        try:
            # Try PyMuPDF first
            documents = self._extract_with_pymupdf(file_path)
            if documents:
                return documents

            # If PyMuPDF fails, try OCR
            logger.info("PyMuPDF extraction failed. Attempting OCR.")
            return self._extract_with_ocr(file_path)
        except Exception as e:
            logger.error(f"Error extracting text from PDF {file_path}: {str(e)}")
            return []

    def _extract_with_pymupdf(self, file_path: str) -> List[Document]:
        try:
            doc = fitz.open(file_path)
            documents = []
            for page_num in range(len(doc)):
                page = doc[page_num]
                text = page.get_text()
                if text.strip():
                    documents.append(Document(
                        page_content=text,
                        metadata={"source": file_path, "page": page_num + 1}
                    ))
            if documents:
                logger.info(f"Successfully extracted text from {len(documents)} pages using PyMuPDF")
            return documents
        except Exception as e:
            logger.warning(f"PyMuPDF extraction failed: {str(e)}")
            return []

    def _extract_with_ocr(self, file_path: str) -> List[Document]:
        logger.info(f"Attempting OCR-based extraction for PDF: {file_path}")
        try:
            images = convert_from_path(file_path, dpi=self.dpi)
            with ThreadPoolExecutor() as executor:
                future_to_page = {executor.submit(self._process_image, image, i + 1, file_path): i for i, image in enumerate(images)}
                documents = []
                for future in as_completed(future_to_page):
                    result = future.result()
                    if result:
                        documents.append(result)
            
            if documents:
                logger.info(f"Successfully extracted text from {len(documents)} pages using OCR")
            else:
                logger.warning(f"No text extracted from PDF using OCR: {file_path}")
            return documents
        except Exception as e:
            logger.error(f"OCR extraction failed: {str(e)}")
            return []

    def _process_image(self, image, page_num: int, file_path: str) -> Optional[Document]:
        try:
            text = pytesseract.image_to_string(image, lang=self.ocr_language)
            if text.strip():
                return Document(
                    page_content=text,
                    metadata={"source": file_path, "page": page_num}
                )
        except Exception as e:
            logger.error(f"Error processing page {page_num}: {str(e)}")
        return None