from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from Models.Models import (
    QueryRequest, 
    QueryResponse, 
    SourceDocument, 
    ModelsResponse,
    ModelSwitchRequest,
    KnowledgeDomainResponse  # Add this new model
)
from typing import List, Dict
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer
from document_processor import DocumentProcessor
from knowledge_domain import KnowledgeDomain
import logging
from rag_system import RAGSystem

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI()

# Configure CORS middleware with more detailed settings
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
    max_age=3600,
)

# Initialize global variables
embedding_name = "all-MiniLM-L6-v2"
doc_processor = None
embedding_model = None
rag_system = None

@app.on_event("startup")
async def startup_event():
    global doc_processor, embedding_model, rag_system
    
    logger.info("Initializing DocumentProcessor")
    doc_processor = DocumentProcessor()
    
    logger.info(f"Initializing embedding model: {embedding_name}")
    embedding_model = SentenceTransformer(embedding_name)
    
    logger.info("Initializing RAGSystem")
    rag_system = RAGSystem(doc_processor, embedding_model)

@app.post("/query", response_model=QueryResponse)
async def query_rag_system(request: QueryRequest):
    try:
        logger.info(f"Received query: {request.question}")
        session_id = request.session_id
        knowledge_domain = request.knowledge_domain or KnowledgeDomain.GENERAL
        logger.info(f"Using session ID: {session_id}, domain: {knowledge_domain}")

        if not session_id:
            raise HTTPException(status_code=400, detail="Session ID is required")

        # Process the query with session ID and knowledge domain
        result = await rag_system.process_query(
            query=request.question,
            session_id=session_id,
            knowledge_domain=knowledge_domain
        )
        
        logger.info("Query processed successfully")
        
        # Convert the result to QueryResponse format
        response = QueryResponse(
            answer=result['answer'],
            question=request.question,
            source_documents=[SourceDocument(**doc) for doc in result['source_documents']]
        )
        return response
    except Exception as e:
        logger.error(f"Error processing query: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/models", response_model=ModelsResponse)
async def get_models():
    """Get available models and current model information."""
    try:
        available_models = rag_system.get_available_models()
        current_model = rag_system.get_current_model()
        logger.info(f"Retrieved models. Current: {current_model}, Available: {available_models}")
        return ModelsResponse(
            available_models=available_models,
            current_model=current_model
        )
    except Exception as e:
        logger.error(f"Error retrieving models: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/switch-model")
async def switch_model(request: ModelSwitchRequest):
    """Switch to a different model."""
    try:
        logger.info(f"Switching to model: {request.model_name}")
        rag_system.switch_model(request.model_name)
        return {"message": f"Successfully switched to model: {request.model_name}"}
    except ValueError as e:
        logger.error(f"Invalid model requested: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error switching model: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/knowledge-domains", response_model=KnowledgeDomainResponse)
async def get_knowledge_domains():
    """Get available knowledge domains."""
    try:
        domains = [domain.value for domain in KnowledgeDomain]
        return KnowledgeDomainResponse(
            available_domains=domains
        )
    except Exception as e:
        logger.error(f"Error retrieving knowledge domains: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/")
async def root():
    return {
        "message": "Welcome to UrBuddy API!",
        "endpoints": {
            "/query": "Submit questions with optional knowledge domain",
            "/models": "Get available models",
            "/switch-model": "Switch between available models",
            "/knowledge-domains": "Get available knowledge domains"
        }
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api:app", host="0.0.0.0", port=8080, workers=1)