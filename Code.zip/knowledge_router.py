from knowledge_domain import KnowledgeDomain
from langchain.schema import Document
import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

class KnowledgeRouter:
    def __init__(self, doc_processor):
        self.doc_processor = doc_processor
        self.domain_handlers = {
            KnowledgeDomain.GENERAL: self.handle_general,
            KnowledgeDomain.WELLS: self.handle_wells,
            KnowledgeDomain.SKKMIGAS: self.handle_skkmigas,
            KnowledgeDomain.DRILLING: self.handle_drilling
        }

    async def route_query(self, query: str, domain: KnowledgeDomain, embedding_model):
        logger.info(f"Routing query to domain: {domain}")
        handler = self.domain_handlers.get(domain)
        if not handler:
            logger.warning(f"Unknown domain: {domain}, falling back to general handler")
            handler = self.handle_general
        
        return await handler(query, embedding_model)

    async def handle_skkmigas(self, query: str, embedding_model):
        """Handle SKKMIGAS domain queries using Data_pdf collection"""
        logger.info("Processing SKKMIGAS domain query")
        try:
            query_vector = embedding_model.encode(query).tolist()
            results = self.doc_processor.search_documents(
                query_vector,
                "Data_pdf",
                limit=5
            )
            
            # Process results safely with proper error handling
            processed_docs = []
            for result in results:
                try:
                    # Safely extract data from result using defensive programming
                    if isinstance(result, dict):
                        metadata = {
                            "source": result.get("document_name", "Unknown"),  # Add source field
                            "document_name": result.get("document_name", "Unknown"),
                            "number_page": result.get("number_page", None)
                        }
                        content = result.get("text", "")
                    else:
                        # If result is not a dict, try to access as object attributes
                        metadata = {
                            "source": getattr(result, "document_name", "Unknown"),  # Add source field
                            "document_name": getattr(result, "document_name", "Unknown"),
                            "number_page": getattr(result, "number_page", None)
                        }
                        content = getattr(result, "text", "")

                    doc = Document(
                        page_content=content,
                        metadata=metadata
                    )
                    processed_docs.append(doc)
                except Exception as e:
                    logger.error(f"Error processing individual result: {str(e)}")
                    continue

            logger.info(f"Successfully processed {len(processed_docs)} documents for SKKMIGAS query")
            
            return {
                "documents": processed_docs,
                "question": query,
                "question_type": KnowledgeDomain.SKKMIGAS
            }
        except Exception as e:
            logger.error(f"Error in SKKMIGAS handler: {str(e)}")
            raise

    async def handle_wells(self, query: str, embedding_model):
        """Handle wells domain queries using wells_data_txt collection"""
        logger.info("Processing wells domain query")
        try:
            # Extract well name from query
            import re
            well_pattern = r'\b([0-9]+[A-Z]-[0-9]+)\b'
            well_match = re.search(well_pattern, query)
            
            if well_match:
                well_name = well_match.group(1)
                logger.info(f"Found well name in query: {well_name}")
                
                fuzzy_results = self.fuzzy_search_well_name(well_name, "Wells_data_txt")
                if fuzzy_results:
                    logger.info(f"Found {len(fuzzy_results)} documents using fuzzy search")
                    processed_docs = self._process_fuzzy_results(fuzzy_results)
                    return {
                        "documents": processed_docs,
                        "question": query,
                        "question_type": KnowledgeDomain.WELLS
                    }
            
            # Fallback to vector search
            logger.info("Using vector search as fallback")
            query_vector = embedding_model.encode(query).tolist()
            vector_results = self.doc_processor.search_documents(
                query_vector,
                "Wells_data_txt",
                limit=5
            )
            
            processed_docs = self._process_well_vector_results(vector_results)
            logger.info(f"Processed {len(processed_docs)} documents using vector search")
            
            return {
                "documents": processed_docs,
                "question": query,
                "question_type": KnowledgeDomain.WELLS
            }
        except Exception as e:
            logger.error(f"Error in wells handler: {str(e)}")
            raise

    def _process_well_vector_results(self, results) -> List[Document]:
        """Process results from vector search for well data"""
        documents = []
        try:
            for hit in results:
                try:
                    if isinstance(hit, dict):
                        metadata = {
                            "source": hit.get("source_document", "Unknown"),
                            "wells_name": hit.get("wells_name", "Unknown"),
                            "page": None
                        }
                        content = hit.get("text", "")
                    else:
                        metadata = {
                            "source": getattr(hit, "source_document", "Unknown"),
                            "wells_name": getattr(hit, "wells_name", "Unknown"),
                            "page": None
                        }
                        content = getattr(hit, "text", "")

                    doc = Document(
                        page_content=content,
                        metadata=metadata
                    )
                    documents.append(doc)
                except Exception as e:
                    logger.error(f"Error processing well vector result: {str(e)}")
                    continue
        except Exception as e:
            logger.error(f"Error in _process_well_vector_results: {str(e)}")
        return documents

    def _process_fuzzy_results(self, results: List[Dict]) -> List[Document]:
        """Process results from fuzzy search"""
        documents = []
        try:
            for result in results:
                try:
                    if isinstance(result, dict):
                        metadata = {
                            "source": result.get("source_document", "Unknown"),
                            "wells_name": result.get("wells_name", "Unknown"),
                            "page": None
                        }
                        content = result.get("text", "")
                    else:
                        metadata = {
                            "source": getattr(result, "source_document", "Unknown"),
                            "wells_name": getattr(result, "wells_name", "Unknown"),
                            "page": None
                        }
                        content = getattr(result, "text", "")

                    doc = Document(
                        page_content=content,
                        metadata=metadata
                    )
                    documents.append(doc)
                except Exception as e:
                    logger.error(f"Error processing fuzzy result: {str(e)}")
                    continue
        except Exception as e:
            logger.error(f"Error in _process_fuzzy_results: {str(e)}")
        return documents

    async def handle_general(self, query: str, embedding_model):
        """Handle general domain queries without vector search"""
        logger.info("Processing general domain query")
        return {
            "documents": [],
            "question": query,
            "question_type": KnowledgeDomain.GENERAL
        }

    async def handle_drilling(self, query: str, embedding_model):
        """Placeholder for drilling domain queries"""
        logger.info("Processing drilling domain query (limited functionality)")
        return {
            "documents": [],
            "question": query,
            "question_type": KnowledgeDomain.DRILLING,
            "message": "Drilling information handling is currently limited"
        }

    def fuzzy_search_well_name(self, well_name: str, collection_name: str) -> List[Dict[str, Any]]:
        """Improved fuzzy search for well names"""
        try:
            logger.info(f"Starting fuzzy search for well: {well_name}")
            all_wells = self.doc_processor.get_all_well_names(collection_name)
            
            if not all_wells:
                logger.warning("No well names found in collection")
                return []

            # Standardize input well name
            well_name = well_name.upper().strip()

            # Exact match first
            exact_matches = [w for w in all_wells if w.upper().strip() == well_name]
            if exact_matches:
                logger.info(f"Found exact matches: {exact_matches}")
                documents = self.doc_processor.search_documents_by_well_names(exact_matches, collection_name)
                return documents

            # Fuzzy matching with more detailed scoring
            from fuzzywuzzy import fuzz
            from fuzzywuzzy import process
            
            matches = []
            for well in all_wells:
                # Calculate multiple types of ratios
                ratio = fuzz.ratio(well_name, well.upper())
                partial = fuzz.partial_ratio(well_name, well.upper())
                token_sort = fuzz.token_sort_ratio(well_name, well.upper())
                
                # Get highest score among different ratio calculations
                score = max(ratio, partial, token_sort)
                
                if score >= 75:  # Lower threshold for more matches
                    matches.append((well, score))

            # Sort by score and get top matches
            matches.sort(key=lambda x: x[1], reverse=True)
            best_matches = [match[0] for match in matches[:3]]  # Get top 3 matches

            if best_matches:
                logger.info(f"Found fuzzy matches: {best_matches}")
                documents = self.doc_processor.search_documents_by_well_names(best_matches, collection_name)
                return documents

            logger.info(f"No matches found for well name: {well_name}")
            return []
            
        except Exception as e:
            logger.error(f"Error in fuzzy search: {str(e)}")
            return []