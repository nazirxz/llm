import logging
from typing import Dict, Any, List
from langchain.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langgraph.graph import END, StateGraph, START
from typing_extensions import TypedDict
from document_processor import DocumentProcessor
from llm_handler import LLMHandler
from knowledge_router import KnowledgeRouter
from knowledge_domain import KnowledgeDomain
from langchain.schema import Document, HumanMessage
from sentence_transformers import SentenceTransformer
from Models.Models import Metadata, SourceDocument
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.chat_history import BaseChatMessageHistory

# Configure logging
def setup_logger(name: str, log_file: str, level=logging.INFO) -> logging.Logger:
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    file_handler = logging.FileHandler(log_file)
    file_handler.setFormatter(formatter)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger

logger = setup_logger('rag_system', 'rag_system.log')

class GraphState(TypedDict):
    question: str
    generation: str
    documents: List[str]
    chat_history: str
    knowledge_domain: str

class RAGSystem:
    def __init__(self, doc_processor: DocumentProcessor, embedding_model: SentenceTransformer, max_documents: int = 3):
        logger.info("Initializing RAGSystem with DocumentProcessor")
        try:
            self.doc_processor = doc_processor
            self.llm_handler = LLMHandler()
            self.llm = self.llm_handler.llm
            self.embedding_model = embedding_model
            self.max_documents = max_documents
            self.knowledge_router = KnowledgeRouter(doc_processor)
            self.chat_history_store = {}

            self.setup_chains()
            self.setup_workflow()
            logger.info("RAGSystem initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing RAGSystem: {str(e)}", exc_info=True)
            raise

    def setup_chains(self):
        try:
            logger.info("Setting up chains")
            
            # General response prompt
            general_prompt = PromptTemplate(
                template="""You are URBuddy, an AI assistant for Pertamina Hulu Rokan. 
                Provide a clear, accurate, and helpful response.
                
                Chat History:
                {chat_history}
                
                Question: {question}
                
                Response:""",
                input_variables=["question", "chat_history"]
            )
            self.general_prompt = general_prompt | self.llm | StrOutputParser()

            # Vector store response prompt
            vectorstore_prompt = PromptTemplate(
                template="""You are URBuddy, an AI assistant for Pertamina Hulu Rokan.
                Use the following context to answer the question accurately:

                Context:
                {context}

                Chat History:
                {chat_history}

                Question: {question}

                Response:""",
                input_variables=["context", "question", "chat_history"]
            )
            self.vectorstore_prompt = vectorstore_prompt | self.llm | StrOutputParser()

            # Introduction handler prompt
            intro_prompt = PromptTemplate(
                template="""You are URBuddy, the professional AI assistant for Pertamina Hulu Rokan.
                Respond to this introduction professionally and briefly explain your capabilities
                regarding oil and gas operations.

                Chat History:
                {chat_history}
                User input: {question}

                Response:""",
                input_variables=["question", "chat_history"]
            )
            self.intro_handler = intro_prompt | self.llm | StrOutputParser()

            logger.info("Chain setup completed successfully")
        except Exception as e:
            logger.error(f"Error setting up chains: {str(e)}", exc_info=True)
            raise

    def setup_workflow(self):
        try:
            logger.info("Setting up workflow")
            workflow = StateGraph(GraphState)

            # Define nodes
            workflow.add_node("route_knowledge", self.knowledge_router.route_query)
            workflow.add_node("handle_general", self.handle_general_response)
            workflow.add_node("handle_vectorstore", self.handle_vectorstore_response)
            workflow.add_node("handle_intro", self.handle_intro)

            # Build graph
            workflow.add_conditional_edges(
                START,
                self.determine_workflow,
                {
                    "introduction": "handle_intro",
                    "knowledge_query": "route_knowledge"
                }
            )

            workflow.add_conditional_edges(
                "route_knowledge",
                self.determine_response_type,
                {
                    "general": "handle_general",
                    "vectorstore": "handle_vectorstore"
                }
            )

            workflow.add_edge("handle_intro", END)
            workflow.add_edge("handle_general", END)
            workflow.add_edge("handle_vectorstore", END)

            self.app = workflow.compile()
            logger.info("Workflow setup completed successfully")
        except Exception as e:
            logger.error(f"Error setting up workflow: {str(e)}", exc_info=True)
            raise
    def determine_workflow(self, state: Dict[str, Any]) -> str:
        """Determine if this is an introduction or knowledge query"""
        question = state["question"].lower()
        if any(word in question for word in ['hello', 'hi', 'greetings', 'introduce']):
            logger.info("Query classified as introduction")
            return "introduction"
        logger.info("Query classified as knowledge query")
        return "knowledge_query"

    def determine_response_type(self, state: Dict[str, Any]) -> str:
        question_type = state.get("question_type", "")
        knowledge_domain = state.get("knowledge_domain", "general")
        logger.info(f"Determining response type for question type: {question_type} in domain: {knowledge_domain}")
        if question_type in [KnowledgeDomain.WELLS, KnowledgeDomain.SKKMIGAS]:
            logger.info("Using vectorstore response handler")
            return "vectorstore"
        logger.info("Using general response handler")
        return "general"

    async def handle_vectorstore_response(
        self, 
        query: str, 
        documents: List[Document], 
        chat_history: str,
        knowledge_domain: str
    ) -> Dict[str, Any]:
        """
        Handle responses that require vector store context
        
        Args:
            query (str): The user's question
            documents (List[Document]): Retrieved relevant documents
            chat_history (str): Formatted chat history
            knowledge_domain (str): Current knowledge domain
            
        Returns:
            Dict[str, Any]: Response with answer and source documents
        """
        try:
            logger.info(f"Handling vectorstore response for query in domain {knowledge_domain}")
            
            if not documents:
                no_docs_message = (
                    f"I couldn't find any relevant {knowledge_domain} documents to answer your question. "
                    "Could you please rephrase your question or ask about something else?"
                )
                return {
                    "question": query,
                    "answer": no_docs_message,
                    "source_documents": [],
                    "domain": knowledge_domain
                }

            # Prepare context from documents
            context = self.prepare_context(documents)
            logger.info("Context prepared from documents")

            # Generate response using vectorstore prompt
            response = await self.vectorstore_prompt.ainvoke({
                "context": context,
                "question": query,
                "chat_history": chat_history
            })
            
            # Process source documents
            source_documents = []
            for doc in documents:
                try:
                    source_doc = SourceDocument(
                        content=doc.page_content[:200] + "...",
                        metadata=Metadata(**doc.metadata)
                    )
                    source_documents.append(source_doc.dict())
                except Exception as doc_error:
                    logger.error(f"Error processing document: {str(doc_error)}")
                    continue
            
            logger.info(f"Vectorstore response generated successfully for domain: {knowledge_domain}")
            return {
                "question": query,
                "answer": response,
                "source_documents": source_documents,
                "domain": knowledge_domain
            }

        except Exception as e:
            logger.error(f"Error in vectorstore response: {str(e)}")
            error_message = (
                "I encountered an error while searching the knowledge base. "
                "Please try rephrasing your question."
            )
            return {
                "question": query,
                "answer": error_message,
                "source_documents": [],
                "domain": knowledge_domain
            }
    
    async def check_ollama_connection(self) -> bool:
        """Check if Ollama server is accessible"""
        try:
            # Simple test query
            await self.general_prompt.ainvoke({
                "question": "test",
                "chat_history": ""
            })
            return True
        except Exception as e:
            logger.error(f"Ollama connection check failed: {str(e)}")
            return False


    async def handle_general_response(
        self, 
        query: str, 
        chat_history: str,
        knowledge_domain: str
    ) -> Dict[str, Any]:
        """
        Handle general knowledge responses
        
        Args:
            query (str): The user's question
            chat_history (str): Formatted chat history
            knowledge_domain (str): Current knowledge domain
            
        Returns:
            Dict[str, Any]: Response without source documents
        """
        try:
            logger.info(f"Handling general response for query in domain: {knowledge_domain}")
            
            try:
                # Generate response using general prompt
                response = await self.general_prompt.ainvoke({
                    "question": query,
                    "chat_history": chat_history
                })
            except Exception as ollama_error:
                if "500 Internal Server Error" in str(ollama_error):
                    logger.error("Ollama server connection error: %s", str(ollama_error))
                    return {
                        "question": query,
                        "answer": "I apologize, but I'm currently having trouble connecting to the language model server. Please try again in a few moments.",
                        "source_documents": [],
                        "domain": knowledge_domain,
                    }
                raise
            
            # Add disclaimer for general domain
            if knowledge_domain == KnowledgeDomain.GENERAL:
                response = "Note: I'm providing a general response as no specific domain was selected.\n\n" + response
            
            logger.info("General response generated successfully")
            return {
                "question": query,
                "answer": response,
                "source_documents": [],
                "domain": knowledge_domain
            }

        except Exception as e:
            logger.error(f"Error in general response: {str(e)}")
            error_message = "I encountered an error while generating a response. Please try asking your question again."
            
            return {
                "question": query,
                "answer": error_message,
                "source_documents": [],
                "domain": knowledge_domain
            }
    def handle_intro(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Handle introduction and greeting responses"""
        try:
            question = state["question"]
            chat_history = state.get("chat_history", "")
            logger.info(f"Handling introduction: {question}")
            
            response = self.intro_handler.invoke({
                "question": question,
                "chat_history": chat_history
            })
            
            logger.info("Introduction handled successfully")
            return {
                "question": question, 
                "generation": response,
                "chat_history": chat_history
            }
        except Exception as e:
            logger.error(f"Error handling introduction: {str(e)}", exc_info=True)
            return {
                "question": question, 
                "generation": "An error occurred while processing the introduction.",
                "chat_history": chat_history
            }

    def prepare_context(self, documents: List[Document]) -> str:
        """Prepare context from documents for response generation"""
        context = []
        for doc in documents:
            if 'wells_name' in doc.metadata:
                context.append(
                    f"Source: {doc.metadata.get('source', 'Unknown')}\n"
                    f"Well: {doc.metadata.get('wells_name', 'Unknown')}\n"
                    f"Content: {doc.page_content}"
                )
            elif 'document_name' in doc.metadata:
                context.append(
                    f"Document: {doc.metadata.get('document_name', 'Unknown')}\n"
                    f"Page: {doc.metadata.get('number_page', 'Unknown')}\n"
                    f"Content: {doc.page_content}"
                )
            else:
                context.append(doc.page_content)
        
        formatted_context = "\n\n".join(context)
        logger.debug(f"Prepared context (first 500 chars): {formatted_context[:500]}...")
        return formatted_context

    # Chat History Management Methods
    def get_session_history(self, session_id: str) -> BaseChatMessageHistory:
        """Get or create chat history for a specific session"""
        if session_id not in self.chat_history_store:
            logger.info(f"Creating new chat history for session {session_id}")
            self.chat_history_store[session_id] = ChatMessageHistory()
        return self.chat_history_store[session_id]

    def get_formatted_chat_history(self, session_id: str) -> str:
        """Get formatted chat history for a specific session"""
        chat_history = self.get_session_history(session_id)
        if not chat_history.messages:
            return ""
        
        formatted_history = []
        for message in chat_history.messages:
            role = "User" if message.type == "human" else "Assistant"
            formatted_history.append(f"{role}: {message.content}")
        
        return "\n".join(formatted_history)

    def update_chat_history(self, session_id: str, role: str, content: str):
        """Update chat history for a specific session"""
        chat_history = self.get_session_history(session_id)
        if role == "human":
            chat_history.add_user_message(content)
        else:
            chat_history.add_ai_message(content)
        logger.info(f"Updated chat history for session {session_id}")
    
    # Model Management Methods
    def switch_model(self, model_name: str):
        """Switch to a different LLM model"""
        try:
            logger.info(f"Switching to model: {model_name}")
            self.llm_handler.switch_model(model_name)
            self.llm = self.llm_handler.llm
            self.setup_chains()
            logger.info(f"Successfully switched to model: {model_name}")
        except Exception as e:
            logger.error(f"Error switching model: {str(e)}")
            raise

    def get_current_model(self) -> str:
        """Get the name of the currently active model"""
        return self.llm_handler.get_current_model()

    def get_available_models(self) -> List[str]:
        """Get list of available models"""
        return list(self.llm_handler.get_available_models().keys())

    async def process_query(
        self, 
        query: str, 
        session_id: str, 
        knowledge_domain: str = KnowledgeDomain.GENERAL
    ) -> Dict[str, Any]:
        """
        Process a query and return the response with source documents.
        """
        logger.info(f"Processing query for session {session_id} in domain {knowledge_domain}: {query}")
        
        try:
            # Get chat history
            chat_history = self.get_formatted_chat_history(session_id)
            
            # Add user message to history
            self.update_chat_history(session_id, "human", query)
            logger.info("Updated chat history with user query")

            # Route query through knowledge router
            try:
                router_result = await self.knowledge_router.route_query(
                    query,
                    knowledge_domain,
                    self.embedding_model
                )
                logger.info(f"Query routed with type: {router_result.get('question_type', 'unknown')}")

                if router_result.get('question_type') == KnowledgeDomain.DRILLING:
                    drilling_message = "I apologize, but drilling information handling is currently limited. I'll try to help with general knowledge."
                    self.update_chat_history(session_id, "assistant", drilling_message)
                    return {
                        "question": query,
                        "answer": drilling_message,
                        "source_documents": [],
                        "domain": KnowledgeDomain.DRILLING
                    }

            except Exception as routing_error:
                logger.error(f"Routing error: {str(routing_error)}")
                raise

            # Generate response based on query type
            try:
                if router_result["question_type"] in [KnowledgeDomain.WELLS, KnowledgeDomain.SKKMIGAS]:
                    response = await self.handle_vectorstore_response(
                        query,
                        router_result["documents"],
                        chat_history,
                        knowledge_domain
                    )
                else:
                    response = await self.handle_general_response(
                        query,
                        chat_history,
                        knowledge_domain
                    )
                logger.info("Response generated successfully")
                
                # Update chat history with assistant's response
                self.update_chat_history(session_id, "assistant", response["answer"])
                
                return response

            except Exception as response_error:
                logger.error(f"Response generation error: {str(response_error)}")
                error_response = self._handle_process_query_error(query, str(response_error), session_id)
                return error_response

        except Exception as e:
            logger.error(f"Critical error in process_query: {str(e)}", exc_info=True)
            error_response = self._handle_process_query_error(query, str(e), session_id)
            return error_response


    def _handle_process_query_error(
        self, 
        query: str, 
        error_msg: str, 
        session_id: str
    ) -> Dict[str, Any]:
        """Handle errors in process_query"""
        error_message = (
            "I apologize, but I encountered an error while processing your query. "
            "Please try asking your question in a different way."
        )
        
        try:
            self.update_chat_history(session_id, "assistant", error_message)
        except Exception as history_error:
            logger.error(f"Failed to update chat history: {str(history_error)}")

        return {
            "question": query,
            "answer": error_message,
            "source_documents": []
        }

    def log_document_details(self, documents: List[Document]):
        """Log details about processed documents"""
        for i, doc in enumerate(documents, 1):
            logger.info(f"Document {i}:")
            logger.info(f"  Source: {doc.metadata.get('source', 'Unknown')}")
            logger.info(f"  Wells Name: {doc.metadata.get('wells_name', 'N/A')}")
            logger.info(f"  Page: {doc.metadata.get('page', 'N/A')}")
            logger.info(f"  Content (first 100 chars): {doc.page_content[:100]}...")