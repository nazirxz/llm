from enum import Enum

class KnowledgeDomain(str, Enum):
    GENERAL = "general"
    WELLS = "wells"
    SKKMIGAS = "skkmigas"
    DRILLING = "drilling"

class CollectionMapping:
    DOMAIN_TO_COLLECTION = {
        KnowledgeDomain.WELLS: "Wells_data_txt",
        KnowledgeDomain.SKKMIGAS: "Data_pdf",
        KnowledgeDomain.GENERAL: None,  # No specific collection for general
        KnowledgeDomain.DRILLING: None   # No collection yet for drilling
    }

    @staticmethod
    def get_collection_name(domain: KnowledgeDomain) -> str:
        return CollectionMapping.DOMAIN_TO_COLLECTION.get(domain)