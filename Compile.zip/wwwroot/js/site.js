﻿let chatBody;
let userInput;
let sessionId;

document.addEventListener('DOMContentLoaded', function () {
    chatBody = document.getElementById('chatBody');
    userInput = document.getElementById('userInput');

    // Get or create session ID
    sessionId = localStorage.getItem('urbuddy_session_id');
    if (!sessionId) {
        sessionId = generateUUID();
        localStorage.setItem('urbuddy_session_id', sessionId);
    }

    const introMessage = "Hello! I'm URBuddy: Teman Pintar Migas, your AI assistant for Pertamina Hulu Rokan. I'm here to help you with information about oil and gas wells. How can I assist you today?";
    addMessageToChat('assistant', introMessage);

    userInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
});

// Function to generate UUID for session ID
function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0,
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

function sendMessage() {
    const userMessage = userInput.value.trim();
    if (userMessage === '') return;

    addMessageToChat('user', userMessage);
    userInput.value = '';

    fetch(`${apiUrl}/query`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            question: userMessage,
            session_id: sessionId
        }),
    })
        .then(response => response.json())
        .then(data => {
            addMessageToChat('assistant', data.answer, data.source_documents);
        })
        .catch((error) => {
            console.error('Error:', error);
            addMessageToChat('assistant', "I'm sorry, but I encountered an error while processing your request. Please try again later.");
        });
}

// Add function to clear session
function clearSession() {
    localStorage.removeItem('urbuddy_session_id');
    sessionId = generateUUID();
    localStorage.setItem('urbuddy_session_id', sessionId);
    chatBody.innerHTML = '';
    const introMessage = "Hello! I'm URBuddy: Teman Pintar Migas, your AI assistant for Pertamina Hulu Rokan. I'm here to help you with information about oil and gas wells. How can I assist you today?";
    addMessageToChat('assistant', introMessage);
}

function addMessageToChat(sender, message, sourceDocuments = null) {
    const messageElement = document.createElement('div');
    messageElement.className = `chat-message ${sender}`;

    // Format the message: convert markdown to HTML
    let formattedMessage = message
        // Replace markdown bold with HTML bold
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        // Replace newlines with HTML line breaks
        .replace(/\n/g, '<br>');

    let messageContent = `<p class="message-content">${formattedMessage}</p>`;

    if (sender === 'assistant' && sourceDocuments && sourceDocuments.length > 0) {
        const sourceDocument = sourceDocuments[0].metadata.source.split('\\').pop();
        messageContent += `<p class="source-document">Source Document: ${sourceDocument}</p>`;
    }

    messageElement.innerHTML = messageContent;
    chatBody.appendChild(messageElement);
    chatBody.scrollTop = chatBody.scrollHeight;
}